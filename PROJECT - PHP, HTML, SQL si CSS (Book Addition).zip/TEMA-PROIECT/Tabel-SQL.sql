CREATE DATABASE IF NOT EXISTS proiectbazededate;
USE proiectbazededate;

CREATE TABLE Books (
    bookID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(255),
    ISBN VARCHAR(13),
    Genre VARCHAR(50),
    Type VARCHAR(50),
    PublicationTour VARCHAR(50),
    Price DECIMAL(10, 2),
    BookCondition VARCHAR(20)
);

CREATE TABLE Inventory (
    bookID INT AUTO_INCREMENT PRIMARY KEY,
    stockLevelUsed INT,
    stockLevelNew INT,
    FOREIGN KEY (bookID) REFERENCES Books(bookID)
);

CREATE TABLE Authors (
    AuthorID INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50),
    lastName VARCHAR(50)
);

CREATE TABLE BookAuthors (
    bookID INT,
    AuthorID INT,
    PRIMARY KEY (bookID, AuthorID),
    FOREIGN KEY (bookID) REFERENCES Books(bookID),
    FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID)
);

CREATE TABLE Publishers (
    publisherID INT AUTO_INCREMENT PRIMARY KEY,
    Country VARCHAR(50)
);

CREATE TABLE BooksPublishers (
    bookID INT,
    publisherID INT,
    PRIMARY KEY (bookID, publisherID),
    FOREIGN KEY (bookID) REFERENCES Books(bookID),
    FOREIGN KEY (publisherID) REFERENCES Publishers(publisherID)
);

CREATE TABLE OrderItems (
    OrderItemID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    bookID INT,
    Quantity INT,
    Price DECIMAL(10, 2),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (bookID) REFERENCES Books(bookID)
);

CREATE TABLE Orders (
    orderID INT AUTO_INCREMENT PRIMARY KEY,
    customerID INT,
    orderDate DATE,
    Subtotal DECIMAL(10, 2),
    Shipping DECIMAL(10, 2),
    Total DECIMAL(10, 2),
    OrderStatus VARCHAR(255),
    FOREIGN KEY (customerID) REFERENCES Customers(customerID)
);

CREATE TABLE Customers (
    customerID INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50),
    lastName VARCHAR(50),
    streetNumber VARCHAR(10),
    streetName VARCHAR(50),
    postalCode VARCHAR(10),
    Province VARCHAR(50),
    Country VARCHAR(50),
    phoneNumber VARCHAR(15)
);
