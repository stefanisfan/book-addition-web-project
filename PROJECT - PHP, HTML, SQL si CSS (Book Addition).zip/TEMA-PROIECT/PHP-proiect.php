<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "proiectbazededate";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexiune eșuată: " . $conn->connect_error);
}

$title = isset($_POST['title']) ? mysqli_real_escape_string($conn, $_POST['title']) : '';
$author = isset($_POST['author']) ? mysqli_real_escape_string($conn, $_POST['author']) : '';
$year = isset($_POST['year']) ? $_POST['year'] : '';
$genre = isset($_POST['genre']) ? mysqli_real_escape_string($conn, $_POST['genre']) : '';
$publisher = isset($_POST['publisher']) ? mysqli_real_escape_string($conn, $_POST['publisher']) : '';
$country = isset($_POST['country']) ? mysqli_real_escape_string($conn, $_POST['country']) : '';
$isbn = isset($_POST['isbn']) ? mysqli_real_escape_string($conn, $_POST['isbn']) : '';
$price = isset($_POST['price']) ? $_POST['price'] : '';
$condition = isset($_POST['condition']) ? mysqli_real_escape_string($conn, $_POST['condition']) : '';
$type = isset($_POST['type']) ? mysqli_real_escape_string($conn, $_POST['type']) : '';

// Descompunerea numelui autorului în prenume și nume de familie
list($firstName, $lastName) = explode(' ', $author, 2);

// Verificarea cărții dacă există deja
$sqlCheck = "SELECT * FROM Books WHERE Title = '$title' AND Genre = '$genre' AND PublicationTour = '$publisher'";
$resultCheck = $conn->query($sqlCheck);

if ($resultCheck->num_rows > 0) {
    echo "Cartea există deja în sistem!";
} else {
    // Informații despre carte în tabela Books
    $sql = "INSERT INTO Books (Title, ISBN, Genre, Type, PublicationTour, Price, BookCondition) 
        VALUES ('$title', '$isbn', '$genre', '$type', '$publisher', '$price', '$condition')";

    if ($conn->query($sql) === TRUE) {
        $book_id = $conn->insert_id;

        // Descompunerea numelui autorilor în prenume și nume de familie
        $authors = explode(',', $author);
        foreach ($authors as $author) {
            list($firstName, $lastName) = explode(' ', trim($author), 2);

            // Informații despre autor în tabela Authors
            $sqlAuthor = "INSERT IGNORE INTO Authors (firstName, lastName) VALUES ('$firstName', '$lastName')";
            $conn->query($sqlAuthor);
			
			// Asocierea autorului cu cartea în tabela BookAuthors
            $sqlBookAuthor = "INSERT INTO BookAuthors (bookID, AuthorID) VALUES ('$book_id', (SELECT AuthorID FROM Authors WHERE firstName='$firstName' AND lastName='$lastName'))";
            $conn->query($sqlBookAuthor);
        }

        // Informații despre editură în tabela Publishers
        $sqlPublisher = "INSERT IGNORE INTO Publishers (Country) VALUES ('$country')";
        $conn->query($sqlPublisher);

        // Obținerea ID-ului pentru editură
        $resultPublisher = $conn->query("SELECT publisherID FROM Publishers WHERE Country='$country'");
        $rowPublisher = $resultPublisher->fetch_assoc();
        $publisher_id = $rowPublisher['publisherID'];

        // Asociați cartea cu editura în tabela BooksPublishers
        $sqlBookPublisher = "INSERT INTO BooksPublishers (bookID, publisherID) VALUES ('$book_id', '$publisher_id')";
        $conn->query($sqlBookPublisher);

        // Informații despre inventar în tabela Inventory
        $stockLevelUsed = isset($_POST['stockLevelUsed']) ? $_POST['stockLevelUsed'] : '';
        $stockLevelNew = isset($_POST['stockLevelNew']) ? $_POST['stockLevelNew'] : '';
        $sqlInventory = "INSERT INTO Inventory (bookID, stockLevelUsed, stockLevelNew) 
                         VALUES ('$book_id', '$stockLevelUsed', '$stockLevelNew')";

        if ($conn->query($sqlInventory) === TRUE) {
            // Informații despre comandă în tabela Orders
            $orderStatus = isset($_POST['orderStatus']) ? $_POST['orderStatus'] : 'In Progress';

            // Subtotal, Shipping și Total - calculare
            $sqlSubtotal = "SELECT SUM(Quantity * Price) AS Subtotal FROM OrderItems WHERE OrderID='$book_id'";
            $resultSubtotal = $conn->query($sqlSubtotal);
            $rowSubtotal = $resultSubtotal->fetch_assoc();
            $subtotal = $rowSubtotal['Subtotal'];

            // Asigurarea subtotalului fiind numeric
            $subtotal = is_numeric($subtotal) ? $subtotal : 0;

            // Taxa de expediere (Shipping) poate fi o valoare fixă sau calculată în funcție de preferință
            $shipping = 10.00; // Exemplu: taxă de expediere de 10.00

            // Calculați Total adăugând Subtotal și Shipping
            $total = $subtotal + $shipping;

            // Informații despre comandă în tabela Orders
            $orderDate = isset($_POST['orderDate']) ? $_POST['orderDate'] : date('Y-m-d');
            $orderStatus = isset($_POST['orderStatus']) ? $_POST['orderStatus'] : 'In Progress';
            $sqlOrder = "INSERT INTO Orders (customerID, orderDate, Subtotal, Shipping, Total, OrderStatus) 
                         VALUES (NULL, NOW(), '$subtotal', '$shipping', '$total', '$orderStatus')";

            if ($conn->query($sqlOrder) === TRUE) {
                $order_id = $conn->insert_id;

                // Informații despre client în tabela Customers
                $firstName = isset($_POST['firstName']) ? mysqli_real_escape_string($conn, $_POST['firstName']) : '';
                $lastName = isset($_POST['lastName']) ? mysqli_real_escape_string($conn, $_POST['lastName']) : '';
                $streetNumber = isset($_POST['streetNumber']) ? $_POST['streetNumber'] : '';
                $streetName = isset($_POST['streetName']) ? mysqli_real_escape_string($conn, $_POST['streetName']) : '';
                $postalCode = isset($_POST['postalCode']) ? $_POST['postalCode'] : '';
                $province = isset($_POST['province']) ? mysqli_real_escape_string($conn, $_POST['province']) : '';
                $phoneNumber = isset($_POST['phoneNumber']) ? mysqli_real_escape_string($conn, $_POST['phoneNumber']) : '';
                $sqlCustomer = "INSERT INTO Customers (firstName, lastName, streetNumber, streetName, postalCode, Province, Country, phoneNumber)
                                VALUES ('$firstName', '$lastName', '$streetNumber', '$streetName', '$postalCode', '$province', '$country', '$phoneNumber')";

                if ($conn->query($sqlCustomer) === TRUE) {
                    // Asocierea comenzii cu clientul în tabela Orders
                    $sqlUpdateOrder = "UPDATE Orders SET customerID='$order_id' WHERE OrderID='$order_id'";
                    $conn->query($sqlUpdateOrder);

                    // Informații despre articolele din comandă în tabela OrderItems
                    $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : '';
                    $itemPrice = isset($_POST['itemPrice']) ? $_POST['itemPrice'] : '';

                    $sqlOrderItem = "INSERT INTO OrderItems (OrderID, bookID, Quantity, Price) 
                                     VALUES ('$order_id', '$book_id', '$quantity', '$itemPrice')";

                    if ($conn->query($sqlOrderItem) === TRUE) {
                        echo "Articol adăugat cu succes în comandă!";
                    } else {
                        echo "Eroare la adăugarea articolului în comandă: " . $conn->error;
                    }
                } else {
                    echo "Eroare la adăugarea clientului: " . $conn->error;
                }
            } else {
                echo "Eroare la adăugarea comenzii: " . $conn->error;
            }
        } else {
            echo "Eroare la adăugarea inventarului: " . $conn->error;
        }
    } else {
        echo "Eroare la adăugarea cărții: " . $conn->error;
    }
}

$conn->close();
?>
